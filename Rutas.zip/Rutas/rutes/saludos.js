const express = require('express')
const router = express.Router()

router.get("/hola",(peticion,respuesta)=>
{respuesta.send("hola")
})
router.get("/hi",(peticion,respuesta)=>
{respuesta.send("hi")
})
router.get("/hellow",(peticion,respuesta)=>
{respuesta.send("hello")
})
router.get(/^\/desped/,(peticion,respuesta)=>
{respuesta.send("despedida")
})
router.post("/hellow",(peticion,respuesta)=>
{respuesta.send("hello")
})
router.all("/hellow",(peticion,respuesta)=>
{respuesta.send("hello")
})

module.exports=router