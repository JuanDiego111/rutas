const express = require('express')
const router = express.Router()

router.get("/futbol",(peticion,respuesta)=>
{respuesta.send("Información de partidos")
})
router.get("/baloncesto",(peticion,respuesta)=>
{respuesta.send("Información de partidos")
})

module.exports=router