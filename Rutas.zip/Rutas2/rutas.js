const express=require('express');
const aplicacion = express();
const rutasConciertos= require('./rutas/conciertos')
const rutasDeportes= require('./rutas/deportes')

aplicacion.use('/conciertos',rutasConciertos)
aplicacion.use('/deportes',rutasDeportes)
aplicacion.get("/",(peticion,respuesta)=>
{respuesta.send("Pagina de Bienvenida")
})

aplicacion.listen(8080,()=>{
    console.log("Servidor iniciado");
})