const express=require('express')
const rout=express.Router()
rout.use("/privada",(peticion,respuesta,siguiente)=>{
    console.log("No ha iniciado sesion");
    respuesta.redirect("/Inicio")
})

module.exports=rout;
